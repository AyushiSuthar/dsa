#include<stdio.h>
#include<stdlib.h>
struct tree {
	char data;
	struct tree *lptr;
	struct tree *rptr;
};
void preorder(struct tree *);
void inorder(struct tree *);
void postorder(struct tree *);
void main ()
{
	struct tree *a,*b,*c,*d,*e,*f,*g,*t;
	a=(struct tree *)malloc(sizeof(struct tree));
	b=(struct tree *)malloc(sizeof(struct tree));
	c=(struct tree *)malloc(sizeof(struct tree));
	d=(struct tree *)malloc(sizeof(struct tree));
	e=(struct tree *)malloc(sizeof(struct tree));
	f=(struct tree *)malloc(sizeof(struct tree));
	g=(struct tree *)malloc(sizeof(struct tree));
	t=a;
	a->data = 'A';
	a->lptr = b;
	a->rptr = d;
	
	b->data = 'B';
	b->lptr = c;
	b->rptr = NULL;
	
	c->data = 'C';
	c->lptr = NULL;
	c->rptr = NULL;

	d->data = 'D';
	d->lptr = e;
	d->rptr = g;

	e->data = 'E';
	e->lptr = NULL;
	e->rptr = f;

	g->data = 'G';
	g->lptr = NULL;
	g->rptr = NULL;

	f->data = 'F';
	f->lptr = NULL;
	f->rptr = NULL;

	printf("Tree in preorder is\n");
	preorder(t);
	printf("\nTree in Inorder is\n");
	inorder(t);
	printf("\nTree in  postorder is\n");
	postorder(t);
}
void preorder(struct tree *t){
	if(t==NULL)
	printf("Empty Tree");
	else
	{
		printf("%c ",t->data);
		if(t->lptr!=NULL)
		preorder(t->lptr);
		if(t->rptr!=NULL)
		preorder(t->rptr);
	}
}
void inorder(struct tree *t){
	if(t==NULL)
	printf("Empty Tree");
	else
	{
		
		if(t->lptr!=NULL)
		inorder(t->lptr);
		printf("%c ",t->data);
		if(t->rptr!=NULL)
		inorder(t->rptr);
	}
}
void postorder(struct tree *t){
	if(t==NULL)
	printf("Empty Tree");
	else
	{
		
		if(t->lptr!=NULL)
		postorder(t->lptr);
		if(t->rptr!=NULL)
		postorder(t->rptr);
		printf("%c ",t->data);
	}
}
